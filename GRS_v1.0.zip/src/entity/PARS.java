package entity;
import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;


public class PARS
{
	private final int n;
	private Pairing pairing;
	private Element G;
	private Element[] pks, sks;
	private Element R, miu;
	private int l;
	private Element[] fs;
    private ArrayList<ArrayList<Element>> delta;
	
	public PARS (int n)
	{
		this.n = n;
	}
	
	public int getN()
	{
		return this.n;
	}
	
	public void setPairing(Pairing pairing)
	{
		this.pairing = pairing;
		return;
	}
	
	public Pairing getPairing()
	{
		return this.pairing;
	}
	
	public void setG(Element G)
	{
		this.G = G;
		return;
	}
	
	public Element getG()
	{
		return this.G;
	}
	
	public void setPks(Element[] pks)
	{
		this.pks = pks;
		return;
	}
	
	public Element[] getPks()
	{
		return this.pks;
	}
	
	public void setSks(Element[] sks)
	{
		this.sks = sks;
		return;
	}
	
	public Element[] getSks()
	{
		return this.sks;
	}
	
	public void setR(Element R)
	{
		this.R = R;
		return;
	}
	
	public Element getR()
	{
		return this.R;
	}
	
	public void setMiu(Element miu)
	{
		this.miu = miu;
		return;
	}
	
	public Element getMiu()
	{
		return this.miu;
	}
	
	public void setL(int l)
	{
		this.l = l;
		return;
	}
	
	public int getL()
	{
		return this.l;
	}
	
	public void setFs(Element[] fs)
	{
		this.fs = fs;
		return;
	}
	
	public Element[] getFs()
	{
		return this.fs;
	}
	
	public void setDelta(ArrayList<ArrayList<Element>> delta)
	{
		this.delta = delta;
		return;
	}
	
	public ArrayList<ArrayList<Element>> getDelta()
	{
		return this.delta;
	}
	
	@Override
	public String toString()
	{
		StringBuffer sb = new StringBuffer();
		sb.append("n = " + n + "\n");
		sb.append("G = " + G + "\n");
		sb.append("pks = " + Arrays.toString(pks) + "\n");
		sb.append("sks = " + Arrays.toString(sks) + "\n");
		sb.append("R = " + R + "\n");
		sb.append("miu = " + miu + "\n");
		sb.append("l = " + l + "\n");
		sb.append("fs = " + Arrays.toString(fs) + "\n");
		sb.append("delta = " + delta + "\n");
		return sb.toString();
	}
	
	
	public static BigInteger getX(Element element)
	{
        return new BigInteger(element.toString().split(",")[0]);
	}
	
	public static Element getX(Element element, Pairing pairing)
	{
		Element newElement = pairing.getZr().newElement();
        newElement.set(PARS.getX(element));
        return newElement;
	}
	
	public static Element concat(Element element1, Element element2, Pairing pairing)
	{
		Element element = pairing.getZr().newElement();
		element.set(new BigInteger(element1.toString().split(",")[0] + element2.toString().split(",")[0]));
		return element;
	}
	
	public static Element H(Element concatenated, Pairing pairing)
	{
		MessageDigest messageDigest;
		try
		{
			messageDigest = MessageDigest.getInstance("SHA-256");
		}
		catch (Exception e)
		{
			throw new RuntimeException(e);
		}
		byte[] hash = messageDigest.digest(concatenated.toBytes());
		return pairing.getZr().newElementFromHash(hash, 0, hash.length);
	}
}
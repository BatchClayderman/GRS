import entity.PARS;
import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import java.util.Random;


public class SignI
{
	public static PARS signI(PARS pars)
	{
		/* Initial PARS */
		System.out.println("/* SignI */");
		int n = pars.getN();
		Pairing pairing = pars.getPairing();
		Element[] pks = pars.getPks();
		Element[] sks = pars.getSks();
		
		/* for i from 1 to n, select ki from zq* randomly */
		Element[] k = new Element[n];
		for (int i = 0; i < n; ++i)
			k[i] = pairing.getZr().newRandomElement();
		
		/* Compute R */
		Element R = pks[0].duplicate().powZn(k[0]);
		for (int i = 1; i < n; ++i)
			R = R.duplicate().mul(pks[i].duplicate().powZn(k[i]));
		pars.setR(R);
		
		/* Compute c */
		Element miu = pairing.getG1().newRandomElement(); // randomly generate miu (message)
		pars.setMiu(miu);
		Element concatenated = PARS.concat(miu.duplicate(), R.duplicate(), pairing);
		for (Element pk : pks)
			concatenated = PARS.concat(concatenated.duplicate(), pk.duplicate(), pairing);
		Element c = PARS.H(concatenated, pairing);
		
		/* Compute f */
		Random random = new Random();
		int l = random.nextInt(n);
		pars.setL(l);
		Element[] fs = new Element[n];
		for (int i = 0; i < n; ++i)
			if (l == i)
				fs[i] = k[i].duplicate().add(c.duplicate().mul(sks[i]));
			else
				fs[i] = k[i].duplicate();
		
		/* Output R and f */
		System.out.println("R = " + R);
		for (Element f : fs)
			System.out.println("f = " + f);
		pars.setFs(fs);
		
		/* Return pars */
		System.out.println();
		return pars;
	}
}
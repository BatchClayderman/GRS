import entity.PARS;
import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import java.util.ArrayList;


public class SignII
{
	public static PARS signII(PARS pars)
	{
		/* Initial PARS */
		System.out.println("/* SignII */");
		int n = pars.getN();
		Pairing pairing = pars.getPairing();
		Element[] pks = pars.getPks();
		Element[] sks = pars.getSks();
		int l = pars.getL();
		
		/* for i from 1 to n, select ki from zq* randomly */
		Element[] k = new Element[n];
		for (int i = 0; i < n; ++i)
			k[i] = pairing.getZr().newRandomElement();
		
		/* Compute R */
		Element R = pks[0].duplicate().powZn(k[0]);
		for (int i = 1; i < n; ++i)
			R = R.duplicate().mul(pks[i].duplicate().powZn(k[i]));
		pars.setR(R);
		
		/* Compute c */
		Element miu = pairing.getG1().newRandomElement(); // randomly generate miu (message)
		pars.setMiu(miu);
		Element concatenated = PARS.concat(miu.duplicate(), R.duplicate(), pairing);
		for (Element pk : pks)
			concatenated = PARS.concat(concatenated.duplicate(), pk.duplicate(), pairing);
		Element c = PARS.H(concatenated, pairing);
		
		/* Compute f */
		Element[] fs = new Element[n];
		for (int i = 0; i < n; ++i)
			if (l == i)
				fs[i] = k[i].duplicate().add(c.duplicate().mul(sks[i]));
			else
				fs[i] = k[i].duplicate();
		
		/* Repeat and loop */
		ArrayList<ArrayList<Element>> delta = new ArrayList<ArrayList<Element>>();
		delta.add(new ArrayList<Element>()); // L_B
		delta.add(new ArrayList<Element>()); // R_B
		delta.add(new ArrayList<Element>()); // R
		delta.add(new ArrayList<Element>()); // f'
		while (n > 1)
		{
			/* Set n' and initial four vectors */
			int n_ = n >> 1;
			Element[] f_L = new Element[n_], f_R = new Element[n - n_], p_L = new Element[n_], p_R = new Element[n - n_];
			for (int i = 0; i < n_; ++i)
			{
				f_L[i] = fs[i].duplicate();
				p_L[i] = pks[i].duplicate();
			}
			for (int i = n_; i < n; ++i)
			{
				f_R[i - n_] = fs[i].duplicate();
				p_R[i - n_] = pks[i].duplicate();
			}
			
			/* Compute L_B and R_B */
			Element L_B = p_L[0].duplicate().powZn(f_R[0]);
			for (int i = 1; i < n_; ++i)
				L_B = L_B.duplicate().mul(p_L[i].duplicate().powZn(f_R[i]));
			delta.get(0).add(L_B);
			Element R_B = p_R[0].duplicate().powZn(f_L[0]);
			for (int i = 1; i < n_; ++i)
				R_B = R_B.duplicate().mul(p_R[i].duplicate().powZn(f_L[i]));
			delta.get(1).add(R_B);
			
			/* Compute x */
			Element x = PARS.H(PARS.concat(L_B, R_B, pairing), pairing);
			
			/* Compute p' and f' */
			Element[] p_s = new Element[n_], f_s = new Element[n_];
			for (int i = 0; i < n_; ++i)
			{
				p_s[i] = p_R[i].duplicate().powZn(x.duplicate().invert()).duplicate().mul(p_L[i].duplicate().powZn(x));
				f_s[i] = f_R[i].duplicate().mul(x).duplicate().add(f_L[i].duplicate().mul(x.duplicate().invert()));
			}
			n = n_;
			pks = p_s;
			fs = f_s;
		}
		
		/* Output delta */
		delta.get(2).add(R);
		delta.get(3).add(fs[0]);
		pars.setDelta(delta); // (L_B, R_B, R, f')
		System.out.println("delta = " + delta);
		
		/* Return pars */
		System.out.println();
		return pars;
	}
}
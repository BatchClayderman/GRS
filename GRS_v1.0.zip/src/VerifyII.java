import entity.PARS;
import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import java.util.ArrayList;
import java.util.Arrays;


public class VerifyII
{
	public static PARS verifyII(PARS pars) throws Exception
	{
		/* Initial PARS */
		System.out.println("/* VerifyII */");
		int n = pars.getN();
		Pairing pairing = pars.getPairing();
		Element G = pars.getG();
		Element[] pks = pars.getPks();
		Element R = pars.getR(), miu = pars.getMiu();
		ArrayList<ArrayList<Element>> delta = pars.getDelta(); // (L_B, R_B, R, f')
		
		/* Compute c */
		Element concatenated = PARS.concat(miu.duplicate(), R.duplicate(), pairing);
		for (Element pk : pks)
			concatenated = PARS.concat(concatenated.duplicate(), pk.duplicate(), pairing);
		Element c = PARS.H(concatenated, pairing);
		
		/* Compute x */
		Element[] x = new Element[delta.get(0).size()];
		for (int i = 0; i < delta.get(0).size(); ++i)
			x[i] = PARS.H(PARS.concat(delta.get(0).get(i), delta.get(1).get(i), pairing), pairing);
		
		/* Compute s */
		Element[] s = new Element[n];
		for (int i = 0; i < n; ++i)
		{
			final int byte_count = delta.get(0).size(); // to speed up
			s[i] = (i & 1) == 1 ? x[byte_count - 1].duplicate().invert() : x[byte_count - 1].duplicate();
			for (int j = 1; j < byte_count; ++j)
				s[i] = s[i].duplicate().mul(((i >> j) & 1) == 1 ? x[byte_count - 1 - j].duplicate().invert() : x[byte_count - 1 - j].duplicate());
		}
		
		/* Compute A and B */
		Element A = R.duplicate().mul(G.duplicate().powZn(c));
		for (int i = 0; i < delta.get(0).size(); ++i)
		{
			Element x_i_inverted = x[i].duplicate().invert();
			A = A.duplicate().mul(delta.get(0).get(i).duplicate().powZn(x[i].duplicate().mul(x[i]))).duplicate().mul(delta.get(1).get(i).duplicate().powZn(x_i_inverted.duplicate().mul(x_i_inverted)));
		}
		Element B = pks[0].duplicate().powZn(delta.get(3).get(0).duplicate().mul(s[0]));
		for (int i = 1; i < n; ++i)
			B = B.duplicate().mul(pks[i].duplicate().powZn(delta.get(3).get(0).duplicate().mul(s[i])));
				
		/* Output A and B */
		System.out.println("A = " + A);
		System.out.println("B = " + B);
		if (!A.equals(B))
		{
			System.out.println("*** Debug Information Starts ***");
			System.out.println(pars);
			System.out.println("c = " + c);
			System.out.println("x = " + Arrays.toString(x));
			System.out.println("s = " + Arrays.toString(s));
			System.out.println("*** Debug Information Ends ***");
			throw new Exception("A and B are not equal. ");
		}
		
		/* Return pars */
		System.out.println();
		return pars;
	}
}
import entity.PARS;
import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;


public class VerifyI
{
	public static PARS verifyI(PARS pars) throws Exception
	{
		/* Initial PARS */
		System.out.println("/* VerifyI */");
		int n = pars.getN();
		Pairing pairing = pars.getPairing();
		Element G = pars.getG();
		Element[] pks = pars.getPks();
		Element R = pars.getR(), miu = pars.getMiu();
		Element[] fs = pars.getFs();
		
		/* Compute c */
		Element concatenated = PARS.concat(miu.duplicate(), R.duplicate(), pairing);
		for (Element pk : pks)
			concatenated = PARS.concat(concatenated.duplicate(), pk.duplicate(), pairing);
		Element c = PARS.H(concatenated, pairing);
		
		/* Compute A */
		Element A = G.duplicate().powZn(c).duplicate().mul(R);
		
		/* Compute B */
		Element B = pks[0].duplicate().powZn(fs[0]);
		for (int i = 1; i < n; ++i)
			B = B.duplicate().mul(pks[i].duplicate().powZn(fs[i]));
		
		/* Output A and B */
		System.out.println("A = " + A);
		System.out.println("B = " + B);
		if (!A.equals(B))
		{
			System.out.println("*** Debug Information Starts ***");
			System.out.println(pars);
			System.out.println("c = " + c);
			System.out.println("*** Debug Information Ends ***");
			throw new Exception("A and B are not equal. ");
		}
		
		/* Return pars */
		System.out.println();
		return pars;
	}
}
# GRS

This is the implementation of the GRS Encryption. 
